// node rodar.js TABELA.tsv SAIDA.PJC
const fs = require('fs'), vm = require('vm'), zlib = require('zlib')
const { DOMParser, XMLSerializer } = require('@xmldom/xmldom')

const ctx = { console, module: undefined }
ctx.self = ctx
vm.createContext(ctx)
for (const f of ['automaTor-vocabulario.js', 'automaTor-padroes.js', 'automaTor-processo.js', 'automaTor-lancador.js',
                 'automaTor-base.js', 'automaTor-montador.js', 'automaTor-tabela.js']) {
    vm.runInContext(fs.readFileSync(__dirname + '/' + f, 'utf8') +
        '\n;globalThis.__ok=1', ctx, { filename: f })
}
// const/let de topo não viram propriedades do contexto: expõe o que precisamos
const g = vm.runInContext(`({ PJC_BASE, pjcLancar, pjcResumirPedido, pjctMontarPedido,
                              PjcMontador: self.PjcMontador, dadosProcessuais, localizarAdvogado })`, ctx)
g.PjcMontador.configurarDom(new DOMParser(), new XMLSerializer())

const [tsvArq, saida] = process.argv.slice(2)
const pedido = g.pjctMontarPedido(fs.readFileSync(tsvArq, 'utf8'), {
    numeroCNJ: '0011965-83.2025.5.15.0089',
    dataLiquidacao: '2026-09-30',
})
// Simula a busca no PJe com os dados deste processo (vindos do gabarito)
const dp = g.dadosProcessuais({
    numeroProcesso: '0011965-83.2025.5.15.0089',
    autuacao:       '13/11/2025',
    valorDaCausa:   'R$ 284.429,98',
    reclamante:     { nome: 'CLAUDINEIA APARECIDA ALVES DE SOUZA', documento: '254.297.468-35' },
    reclamada:      { nome: 'TB SERVICOS, TRANSPORTE, LIMPEZA, GERENCIAMENTO E RECURSOS HUMANOS S.A.',
                      documento: '60.924.040/0001-51' },
    advogadosReclamante: [{ nome: 'HENRIQUE BRAGANCA PINHEIRO CECATTO', documento: '46967381830', oab: 'SP 501.265' }],
    advogadosReclamada:  [{ nome: 'INAMARA RUDOF VIEIRA BONI', documento: '31186060883', oab: 'SP267158' }],
})
console.log('── dadosProcessuais: erros', dp.erros, 'avisos', dp.avisos)
pedido.processo = dp.processo
const cred = g.localizarAdvogado(dp.processo, 'Henrique Bragança Pinheiro Cecato')
console.log('── credor dos honorários (tabela → cadastro):', cred && cred.nome, cred && cred.numeroDocumento)
console.log('── Pedido'); console.log(JSON.stringify(
    Object.fromEntries(Object.entries(pedido).filter(([k]) => !k.startsWith('__'))), null, 1))
console.log('── Não suportado pelo Pedido'); pedido.__naoSuportado.forEach(x => console.log('  •', x))

const r = g.pjcLancar(pedido)
console.log('── Lançador: erros', r.erros, 'avisos', r.avisos)
if (r.erros.length) process.exit(1)
g.pjcResumirPedido(r.ficha).forEach(l => console.log('  ', l))

const m = g.PjcMontador.montarXml(r.ficha, g.PJC_BASE)
console.log('── Montador: avisos'); m.avisos.forEach(a => console.log('  •', a))

const nome = 'GERADO.PJC'
const zip = g.PjcMontador.empacotar(m.xml, nome, b => zlib.deflateRawSync(Buffer.from(b)))
fs.writeFileSync(saida, Buffer.from(zip))
fs.writeFileSync(saida + '.xml', m.xml)
console.log('── gravado', saida, zip.length, 'bytes')
